from datetime import datetime


def is_match_ended(
    state: str | None,
    endtime: datetime,
    now: datetime,
) -> bool:
    """Check whether a match is considered ended."""
    return (
        state == 'finished'
        or now >= endtime
    )

def is_match_in_progress(
    state: str | None,
    starttime: datetime,
    endtime: datetime,
    now: datetime,
) -> bool:
    """Check whether a match has started and has not ended or cancelled."""
    return (
        starttime <= now
        and not is_match_ended(state, endtime, now)
        and not is_match_cancelled(state)
    )

def is_match_cancelled(
    state: str | None,
) -> bool:
    """Check whether a match will not be played."""
    return (
        state in ('postponed', 'generalForfeit', 'forfeitByOneTeam')
    )
